"use client";
import React, { useRef, useEffect, useState, memo } from "react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import Image from "next/image";
import Quotes from "../../../public/images/quote-left.png";
import { testimonialData } from "@/utils/07utilhomtestim";

// Memoized Testimonial Item Component
const TestimonialItem = memo(({ testimonial }) => (
  <div>
    <div className="row align-items-center image-content-testimonial">
      <div className="col-sm-4 col-xs-12">
        <div className="image-left">
          <Image
            src={testimonial.image}
            alt={testimonial.name}
            width={500}
            height={340}
            loading="lazy" // Lazy load for performance
            // priority={testimonial.id === 1} // Prioritize loading for the first testimonial if desired
          />
        </div>
      </div>
      <div className="col-sm-6 col-xs-12">
        <div className="content-right">
          <Image
            src={Quotes}
            alt="Quotes icon"
            className="quote-main"
            loading="lazy"
          />
          <h4>{testimonial.name}</h4>
          <p>{testimonial.description}</p>
        </div>
      </div>
    </div>
  </div>
));

const HomeTestimonial = () => {
  const slider1Ref = useRef(null); // Ref for main slider
  const slider2Ref = useRef(null); // Ref for navigation slider

  const [nav1, setNav1] = useState(null);
  const [nav2, setNav2] = useState(null);

  useEffect(() => {
    setNav1(slider1Ref.current);
    setNav2(slider2Ref.current);
    
    // Cleanup function to avoid memory leaks
    return () => {
      setNav1(null);
      setNav2(null);
    };
  }, []);

  const settingsMain = {
    autoplay: true,
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    asNavFor: nav2,
  };

  const settingsNav = {
    autoplay: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    asNavFor: nav1,
    dots: false,
    centerMode: true,
    focusOnSelect: true,
    arrows: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 4,
          arrows: true,
          centerMode: true,
        },
      },
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 3,
          arrows: true,
          centerMode: true,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 3,
          arrows: true,
          centerMode: true,
        },
      },
      {
        breakpoint: 668,
        settings: {
          slidesToShow: 2,
          arrows: true,
          centerMode: true,
        },
      },
      {
        breakpoint: 375,
        settings: {
          slidesToShow: 2,
          arrows: true,
          centerMode: true,
        },
      },
    ],
  };

  return (
    <section className="testimonial-main py-5">
      <div className="container">
        <div className="row">
          <div className="col-sm-12 col-xs-12">
            <div className="heading-main text-center pb-5">
              <h2>
                Client <span>Testimonials</span>
              </h2>
              <span>
                Hear from Satisfied Clients about their Experience Working with WebGuruz.
              </span>
            </div>
            <Slider
              {...settingsMain}
              ref={slider1Ref}
              className="testimonial-top"
            >
              {testimonialData.map((testimonial) => (
                <TestimonialItem key={testimonial.id} testimonial={testimonial} />
              ))}
            </Slider>
            <div className="navtestimonial">
              <Slider
                {...settingsNav}
                ref={slider2Ref}
                className="slider-thumbnail"
              >
                {testimonialData.map((testimonial) => (
                  <div key={testimonial.id}>
                    <Image
                      src={testimonial.image}
                      alt={testimonial.name}
                      width={340}
                      height={340}
                      loading="lazy"
                    />
                  </div>
                ))}
              </Slider>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HomeTestimonial;
